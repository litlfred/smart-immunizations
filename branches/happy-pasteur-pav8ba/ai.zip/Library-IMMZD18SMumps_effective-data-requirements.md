# Library - WHO Immunization Implementation Guide v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* [**IMMZ.D18.S.Mumps schedule**](PlanDefinition-IMMZD18SMumps.md)
* **Library**

## Library: Library 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/immunizations/PlanDefinition/IMMZD18SMumps#effective-data-requirements | *Version*:0.2.0 |
| Draft | *Computable Name*:EffectiveDataRequirements |

