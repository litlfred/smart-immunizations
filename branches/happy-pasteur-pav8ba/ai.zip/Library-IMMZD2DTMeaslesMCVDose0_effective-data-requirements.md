# Library - WHO Immunization Implementation Guide v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* [**IMMZ.D2.DT.Measles.MCV dose 0**](PlanDefinition-IMMZD2DTMeaslesMCVDose0.md)
* **Library**

## Library: Library 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/immunizations/PlanDefinition/IMMZD2DTMeaslesMCVDose0#effective-data-requirements | *Version*:0.2.0 |
| Draft | *Computable Name*:EffectiveDataRequirements |

