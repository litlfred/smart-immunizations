# Library - WHO Immunization Implementation Guide v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* [**IMMZ.D18.S.Polio.Birth dose schedule**](PlanDefinition-IMMZD18SPolioBirthDose.md)
* **Library**

## Library: Library 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/immunizations/PlanDefinition/IMMZD18SPolioBirthDose#effective-data-requirements | *Version*:0.2.0 |
| Draft | *Computable Name*:EffectiveDataRequirements |

